# Demetrios Showcase — Design Direction

## Three initial approaches

### Theme Name: Field Signal
Very Brief Intro: A warm editorial field-journal aesthetic that pairs botanical greens with instrument-panel details, making robotics feel approachable and tactile.
Probability: 0.03

### Theme Name: Orbit Command
Very Brief Intro: A dark sci-fi mission-control system with luminous cyan telemetry, glass panels, and cinematic rover imagery for an advanced, pitch-ready feeling.
Probability: 0.08

### Theme Name: Mineral Circuit
Very Brief Intro: A mineral-toned industrial design language with charcoal, oxidized copper, and chalk white, positioning Demetrios as rugged precision hardware.
Probability: 0.02

## Selected Approach: Orbit Command

### Design Movement
Contemporary mission-control brutalism: the clarity of NASA instrumentation translated into a cinematic product narrative, with restrained glassmorphism and hard-edged data geometry.

### Core Principles
1. Make the rover the hero; interface chrome exists to frame its capability.
2. Contrast cinematic scale with precise telemetry labels and instrument-like microcopy.
3. Use asymmetry, hairline rules, and measured negative space instead of generic centered cards.
4. Every interaction should feel like a command acknowledged by a real machine.

### Color Philosophy
A near-black graphite base gives the product visual authority and lets information glow selectively. Electric cyan is the signature signal color for live data, while a small amount of acid lime indicates active field intelligence and forward motion. Soft mineral white keeps the page readable without becoming clinical.

### Layout Paradigm
A vertical expedition: a full-bleed hero with a scroll-expansion rover visual, followed by staggered split sections that alternate between narrative and instrumentation. Content should feel pinned to a control surface rather than arranged as a conventional marketing grid.

### Signature Elements
- Cyan instrument ticks, coordinates, and scanning lines.
- Translucent graphite panels with crisp 1px dividers.
- A recurring circular rover-radar motif used for telemetry and navigation affordances.

### Interaction Philosophy
Buttons feel like physical controls: direct, compact, and immediately acknowledged. Hover states brighten the signal line and shift the control by a few pixels; active states compress slightly. Demo controls are clearly labeled as simulated until hardware is connected.

### Animation
Use short, high-confidence transitions under 300ms for controls and navigation. Let hero media expand with scroll progress, while telemetry pulses gently only when marked live. Stagger section entrances in 40–60ms increments. Respect reduced motion by replacing expansion and pulsing with instant state changes.

### Typography System
Use Space Grotesk for headlines and UI numerals, with IBM Plex Mono for coordinates, labels, status text, and measurement readouts. Headlines are compact and slightly tracked; supporting copy is calm and wide enough for scanning.

### Brand Essence
Demetrios is the field intelligence system for builders who want to pilot, measure, and understand the ground in one decisive pass.
Personality: Precise, exploratory, quietly formidable.

### Brand Voice
Headlines are declarative and cinematic. CTAs are terse commands, not generic marketing filler. Microcopy names the system state plainly.

Example lines:
- “Drive deeper into the signal.”
- “Pilot the rover. Read the field.”

### Wordmark & Logo
A custom geometric mark built from two opposing chevrons orbiting a central sensor dot, suggesting dual motors, a scanning field, and a rover seen from above. The symbol should work independently as the app icon and favicon; the wordmark uses a wide technical grotesk treatment rather than a default font.

### Signature Brand Color
Signal Cyan — #8FF3E8. It is bright enough to read as live instrumentation against graphite, but softer and more refined than a generic neon blue.

## Implementation Notes

- The supplied 21st.dev ScrollExpandMedia concept will be adapted to a React + Vite static environment rather than Next.js, using regular image elements and local scroll progress.
- Product visuals will be generated as web-ready assets and referenced through the WebDev storage workflow.
- The showcase will clearly distinguish presentational demo telemetry from actual hardware-connected real-time data; no live hardware API is fabricated in this static frontend.
- Visual direction chosen: **Orbit Command**.
