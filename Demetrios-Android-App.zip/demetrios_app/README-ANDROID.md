# Demetrios Android App

This project is the Demetrios React/Vite app prepared for Android packaging with Capacitor.

## Build the APK

Requirements:
- Node.js 20+
- Android Studio with Android SDK
- Java 17

Commands:

```bash
npm install
npm run android:add
npm run android:apk
```

The debug APK will be generated under:

`android/app/build/outputs/apk/debug/app-debug.apk`

For Android Studio:

```bash
npm run android:sync
npm run android:open
```

Then select the Android app and press Run.

## App identity

- App name: Demetrios
- Package ID: com.demetrios.fieldrover
- Web app: React + Vite
- Native wrapper: Capacitor

The UI uses local fallback artwork for the demo images that were originally served through a Manus-only storage route, so the packaged app does not depend on that route.
