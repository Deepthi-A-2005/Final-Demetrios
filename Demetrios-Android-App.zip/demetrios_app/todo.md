# Demetrios App-Style Revision

- [x] Replace the cinematic showcase shell with a mobile-first app viewport and soft mint/cream design tokens.
- [x] Implement bottom-tab navigation for Mission, Drive, Analysis, and Settings.
- [x] Build the System Overview screen to match the supplied reference hierarchy and card rhythm.
- [x] Add interactive Drive controls with command state and battery/speed readouts.
- [x] Add Analysis charts, crop recommendation, and field image panel.
- [x] Add Settings and demo Login screens with clearly labeled demo behavior.
- [x] Verify responsive mobile layout, keyboard-accessible controls, and production build.
