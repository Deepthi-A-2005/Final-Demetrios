# Demetrios Smart Field Rover

This folder is a Vite wrapper around the original standalone Demetrios HTML app.

## Run

1. Open a terminal in this folder.
2. Run `npm install`.
3. Run `npm run dev`.
4. Open the localhost URL shown by Vite (normally http://localhost:5173).

## Production build

Run `npm run build`, then `npm run preview`.

## Notes

The original Arduino sketch is included as `demetrios_ble_peripheral.ino`.
The app remains a single HTML/CSS/JS page; Vite is only being used to provide the missing npm project structure and dev server.
