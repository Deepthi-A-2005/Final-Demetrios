# Demetrios PWA

This version is a Progressive Web App (PWA). It does not require Android Studio, Gradle, or an Android SDK.

## Deploy
Upload the contents of this folder to any HTTPS static hosting service (for example Netlify, Vercel, or GitHub Pages).

Important: the app must be served over HTTPS for installation/service-worker features to work (localhost is also okay for testing).

## Install on Android
1. Open the deployed website in Chrome.
2. Tap the three-dot menu.
3. Choose **Install app** or **Add to Home screen**.
4. Open **Demetrios** from your home screen.

## Notes
The existing ESP32-CAM/Bluetooth code remains unchanged. A PWA can use browser capabilities, but native BLE/background hardware features may require a native wrapper later.
